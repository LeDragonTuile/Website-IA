"use client"

import { useState } from "react"
import { MessageCircle, X, Send } from "lucide-react"

const sampleMessages = [
  {
    role: "bot" as const,
    text: "Welcome to TimeTravel Agency. How can I assist you with your next journey through time?",
  },
  {
    role: "user" as const,
    text: "What safety measures do you have for the Cretaceous expedition?",
  },
  {
    role: "bot" as const,
    text: "Our Cretaceous expeditions include a personal force-field generator, a trained temporal guide, and a real-time extraction system. Your safety is our absolute priority.",
  },
]

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [inputValue, setInputValue] = useState("")

  return (
    <>
      {/* Floating button - larger on mobile */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_4px_30px_oklch(0.80_0.13_75/0.3)] transition-all duration-400 active:scale-95 hover:scale-105 hover:shadow-[0_4px_40px_oklch(0.80_0.13_75/0.45)] sm:bottom-8 sm:right-8 ${
          isOpen ? "pointer-events-none scale-0 opacity-0" : "scale-100 opacity-100"
        }`}
        aria-label="Open chat"
      >
        <MessageCircle size={22} />
      </button>

      {/* Chat window - full width on mobile, fixed width on desktop */}
      <div
        className={`fixed z-50 flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card shadow-[0_20px_80px_oklch(0_0_0/0.5),0_0_40px_oklch(0.80_0.13_75/0.05)] transition-all duration-500 ${
          /* Mobile: inset from edges; Desktop: fixed bottom-right */
          "bottom-0 left-0 right-0 h-[85dvh] sm:bottom-8 sm:left-auto sm:right-8 sm:h-auto sm:w-[380px] sm:rounded-2xl"
        } ${
          isOpen
            ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
            : "pointer-events-none translate-y-8 scale-95 opacity-0 sm:translate-y-4"
        }`}
        role="dialog"
        aria-label="Chat with TimeTravel Agency"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border/50 bg-secondary/50 px-5 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-primary">
              <MessageCircle size={16} className="text-primary-foreground" />
              {/* Online indicator */}
              <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-card bg-emerald-500" />
            </div>
            <div>
              <p className="font-sans text-sm font-semibold text-foreground">
                Temporal Concierge
              </p>
              <p className="font-sans text-[10px] font-medium uppercase tracking-[0.15em] text-primary">
                Online
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors duration-200 hover:bg-muted hover:text-foreground active:bg-muted"
            aria-label="Close chat"
          >
            <X size={18} />
          </button>
        </div>

        {/* Messages */}
        <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6" style={{ maxHeight: "calc(85dvh - 140px)", minHeight: 0 }}>
          {sampleMessages.map((msg, i) => (
            <div
              key={i}
              className={`flex ${
                msg.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 font-sans text-[14px] leading-relaxed sm:max-w-[82%] sm:text-[13px] ${
                  msg.role === "user"
                    ? "rounded-br-md bg-primary text-primary-foreground"
                    : "rounded-bl-md border border-border/50 bg-secondary/80 text-secondary-foreground"
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>

        {/* Input - safe area padding for iOS */}
        <div className="border-t border-border/50 bg-secondary/30 px-4 py-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:px-5 sm:pb-4">
          <form
            className="flex items-center gap-3"
            onSubmit={(e) => e.preventDefault()}
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask about time travel..."
              className="flex-1 rounded-xl border border-border/60 bg-background px-4 py-3.5 font-sans text-[15px] text-foreground placeholder:text-muted-foreground/60 focus:border-primary/50 focus:outline-none focus:ring-1 focus:ring-primary/30 sm:py-3 sm:text-sm"
            />
            <button
              type="submit"
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-all duration-200 active:scale-90 hover:bg-primary/90 hover:shadow-[0_0_20px_oklch(0.80_0.13_75/0.2)] sm:h-11 sm:w-11"
              aria-label="Send message"
            >
              <Send size={16} />
            </button>
          </form>
        </div>
      </div>
    </>
  )
}
